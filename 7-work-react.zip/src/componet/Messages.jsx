const addMessage = () => {
   const random = Math.random()
   const obj = {
      id: random,
      chaId: idd,  
      type: DELETE_MESSAGES,
   }
   dispatchEvent({type: ADD_MESSAGE, payload: obj})
};

const deleteMessage = (id) => {
   dispatch({ type: DELETE_MESSAGES, payload: id, }})
};