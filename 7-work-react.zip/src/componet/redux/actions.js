import {DELETE_MESSAGES} from "./actions/actionsTypes";

export const deleteMessages = (id) => ({
   type: DELETE_MESSAGES,
   payload: id
});

export const addMessage = (number) => ({
   type: deleteMessage,
   payload: number
});