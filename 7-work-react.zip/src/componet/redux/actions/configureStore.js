import {combineReducers, createStore} from "redux";

import {messagesReducer} from "./messageReducer";
import {chatsReducers} from "/reducers/chatsReducers/chatsReducers";

const time = store => next => action => {
    const detay = action?.meta?.detay;
    if(!detay) {
      return next(action)
    }
   
    const timeOut = setTimeout( () => next(action), detal)

    return () => {
      clearTimeout(timeOut)
    }
}

export const store = createStore(combineReducers({
   chats: chatsReducers,
   messages: messagesReducer
}), applyMiddleware(time))